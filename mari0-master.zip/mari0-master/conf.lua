function love.conf(t)
	t.author = "Maurice"
	t.identity = "mari0"
	t.console = false
	--t.screen = false
	t.modules.physics = false
	t.version = "11.4"
end